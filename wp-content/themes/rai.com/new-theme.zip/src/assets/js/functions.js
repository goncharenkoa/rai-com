$( document ).ready(function() {
    var dropdown = new Foundation.DropdownMenu($(".dropdown"), {});

});
$('#shop .owl-carousel').owlCarousel({
    nav: true,
    items: 4,
    navigation: true,
    margin: 10

});
$('#news .owl-carousel').owlCarousel({
    items: 4,
    navigation: true,
    margin: 20

});
$('#statuts .owl-carousel').owlCarousel({
    items: 2,
    navigation: true,
    margin: 20

});
$('#gallery .owl-carousel').owlCarousel({
    items: 1,
    navigation: true,
    pagination: false

});
$(".go-bot").click(function(){
    $('body, html').animate({ scrollTop: $($(this).attr("href")).position().top }, 400);
    return false;
});
$(document).ready(function() {
    $(".various").fancybox({
        maxWidth	: 800,
        maxHeight	: 600,
        fitToView	: false,
        width		: '70%',
        height		: '70%',
        autoSize	: false,
        closeClick	: false,
        openEffect	: 'none',
        closeEffect	: 'none'
    });
});